# HS3UKA_PCF8574 Arduino Library

![Arduino](https://img.shields.io/badge/Arduino-Library-brightgreen)

This Arduino library provides easy-to-use functions to interface with the PCF8574 I/O expander. The library includes the following functions:

- `begin(address)`: Initialize the PCF8574 with the specified I2C address.
- `digitalRead(pin)`: Read the digital state of a specific pin on the PCF8574.
- `digitalWrite(pin, value)`: Set the digital state of a specific pin on the PCF8574.

## Installation

1. Download the library ZIP file from the [releases page](https://github.com/your-username/HS3UKA_PCF8574/releases).
2. Open the Arduino IDE and go to Sketch -> Include Library -> Add .ZIP Library.
3. Select the downloaded ZIP file and click "Open."

## Usage

```cpp
#include <HS3UKA_PCF8574.h>

HS3UKA_PCF8574 pcf8574;

void setup() {
    pcf8574.begin(0x20);  // Set the PCF8574 address
}

void loop() {
    int pinValue = pcf8574.digitalRead(0);  // Read the state of pin 0
    pcf8574.digitalWrite(1, HIGH);  // Set pin 1 to HIGH
    delay(1000);
    pcf8574.digitalWrite(1, LOW);  // Set pin 1 to LOW
    delay(1000);
}
